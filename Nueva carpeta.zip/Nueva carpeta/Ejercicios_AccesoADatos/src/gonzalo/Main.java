package gonzalo;

import java.io.File;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner (System.in);

		String directorio;
		
		System.out.println("Introduzca un directorio");
		directorio = teclado.nextLine();
		
		File nombre = new File(directorio);
		nombre.isDirectory();
		
		if (nombre.isDirectory()) {
			System.out.println("Nombre: " + nombre.getName());
			System.out.println("Ruta: " + nombre.getPath());
			System.out.println("Ruta absoluta: " + nombre.getAbsolutePath());
			System.out.println("Puede ejecutar el directorio: " + nombre.canExecute());
			System.out.println("Puede leer el directorio: " + nombre.canRead());
			
		}
		
		else {
			System.out.println("No existe");
		}
		
		
	}

	

}
