package gonzalo;

import java.io.File;
import java.io.FileFilter;

public class Filtro implements FileFilter{

	protected String extension;
	
	public Filtro (String extension) {

		this.extension = extension;
		
	}

	@Override
	public boolean accept(File f) {
		
		if(f.getName().endsWith(extension)) {
			return true;
		}else {
			return false;
		}
		
	}

}
