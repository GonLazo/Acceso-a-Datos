package gonzalo;

import java.io.File;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner (System.in);
		
		String nombre;
		String ex;
		
		System.out.println("Introduzca un directorio: ");
		nombre = teclado.nextLine();
		
		System.out.println("Introduzca una extensión: ");
		ex = teclado.nextLine();
		Filtro filtro = new Filtro(ex);
		
		File f = new File(nombre);
		
		for (File extension : f.listFiles()) {
			if(filtro.accept(extension) || ex.equals(null) || ex.equals(".")) {
				System.out.println(extension.getName());
			}

		}
		
	}

}
