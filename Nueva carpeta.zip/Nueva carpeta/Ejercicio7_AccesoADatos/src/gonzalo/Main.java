package gonzalo;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		

		Scanner teclado = new Scanner (System.in);
		
		String nombre;
	
		ArrayList<Filtro2> filtrar = new ArrayList<>();
		
		System.out.println("Introduzca un directorio: ");
		nombre = teclado.nextLine();
		File f = new File(nombre);
		
		System.out.println("Elija una o varias de las extensiones: .txt,.bmp,.jpg,.java");
		String anyadirextension = teclado.nextLine();
		String[] Array = anyadirextension.split("\\s*,\\s*");
		
		for (String extension : Array) {
			Filtro2 filtro3 = new Filtro2(extension);
			filtrar.add(filtro3);
		}
		
		
		for (File extension : f.listFiles()) {
			for(Filtro2 filtros : filtrar) {
				if(filtros.accept(extension)) {
					System.out.println(extension.getName());
				}
			}
			
		}

	}

}
