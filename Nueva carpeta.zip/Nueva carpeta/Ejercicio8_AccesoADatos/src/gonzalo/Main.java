package gonzalo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
	Scanner teclado = new Scanner (System.in);
		
		
	String archivo;
	
	System.out.println("Introduzca la ruta del fichero: ");
	archivo = teclado.nextLine();
	
	File f = new File(archivo);	
	
	try {
		FileReader fr = new FileReader(f);
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	}
	
	BufferedReader br = new BufferedReader();
	
	
	

	}

}
