/**
 * 
 */
/**
 * 
 */
module AEV2_Streams {
	requires java.desktop;
}