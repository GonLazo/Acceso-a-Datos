package Gonzalo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Controlador {

	 private Vista v;
	 private Model m;
	
	public Controlador(Vista vista, Model modelo) {
		 
		this.v = vista;
		this.m = modelo;
		mostrarLectura();
		botones();
		
	}


	public void mostrarLectura () {
	
		v.getTextAreaOriginal().setText(m.getLectura().toString());
	}
	
	public void botones() {
		
		v.getBtnBuscar().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String word = v.getTextFieldBuscar().getText();
				JOptionPane.showMessageDialog(new JFrame(), " La palabra: |" + word  + "| sale " + m.botonBuscar(word) + " veces", "Resultado", JOptionPane.INFORMATION_MESSAGE);
			}
			});
		
		v.getBtnReemplazar().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
		
			}
			});
	}

}
