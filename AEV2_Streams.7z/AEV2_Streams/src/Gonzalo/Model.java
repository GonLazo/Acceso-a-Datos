package Gonzalo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Model {
	
	static File f = new File ("texto.txt");
	
	public Model() {
		
	}
	
	public static ArrayList<String> getLectura () {
		
		ArrayList <String> lista = new ArrayList<String>();
		
		try {
			
			String linea;
			
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
				
			while((linea = br.readLine()) != null) {
		
				lista.add(linea);
			} 
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return lista;
		
	}
	
	public int botonBuscar (String word) {
		
		int contador = 0;
		String [] comprobacion;
		
		try {
			
			String linea;
			
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
				
			while((linea = br.readLine()) != null) {
		
				comprobacion = linea.split(" ");
				
				for(int i = 0; i < comprobacion.length; i++) {
					if(comprobacion[i].equals(word)) {
						contador++;
					}
				}
			} 
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return contador;
	}
	
	public static ArrayList<String> botonReemplazar (String word, String newWord) {
		
		int contador = 0;
		String [] comprobacion;
		
		try {
			
			String linea;
			
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			
			
				
			while((linea = br.readLine()) != null) {
		
				comprobacion = linea.split(" ");
				
				for(int i = 0; i < comprobacion.length; i++) {
					if(comprobacion[i].equals(newWord)) {
						
					}
				}
			} 
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return null;
		
	}

}
