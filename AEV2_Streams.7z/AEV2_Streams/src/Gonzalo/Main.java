package Gonzalo;

public class Main {

	public static void main(String[] args) {
		
			Vista vista = new Vista();
			Model modelo = new Model();
			Controlador controlador = new Controlador(vista, modelo);
			
			}
	}


