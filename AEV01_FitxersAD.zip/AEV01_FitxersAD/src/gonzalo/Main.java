package gonzalo;

import java.io.File;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in); 

		String directorio;
		int eleccion;
		
		
		
		System.out.println("Introduzca un directorio o fichero de trabajo:");
		directorio = teclado.nextLine();
		
		File nombre = new File(directorio);
		nombre.isDirectory();
		
		System.out.println("¿Qué desea hacer?");
		System.out.println("1) Mostrar información");
		System.out.println("2) Crear una carpeta");
		System.out.println("3) Crear un fichero");
		System.out.println("4) Eliminar carpeta o fichero");
		System.out.println("5) Renombrar carpeta o fichero");
		eleccion = teclado.nextInt();
		
		switch(eleccion) {
		case 1:
			
			getInformacion(nombre);
			
			break;
		case 2:
			teclado.nextLine();
			String nombreC;
			
			System.out.println("Introduzca la ruta y un nombre para la carpeta");
			nombreC = teclado.nextLine();
		
			crearCarpeta(nombreC);
				
			
			
			break;
		case 3:
			teclado.nextLine();
			String nombreFichero;
			
			System.out.println("Introduzca la ruta y un nombre para el fichero");
			nombreFichero = teclado.nextLine();
			
			File fichero = new File (nombreFichero);
			
			try {
				if (fichero.createNewFile()) {
					System.out.println("El fichero se ha creado correctamente");
				}else {
					
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			break;
		case 4:
	
			teclado.nextLine();
			String eliminarArchivo;
			
			System.out.println("Introduzca la ruta y un nombre para eliminar la carpeta o fichero");
			nombreFichero = teclado.nextLine();
			
			File eliminar = new File (nombreFichero);
			
			try {
				if (eliminar.delete()) {
					System.out.println("El archivo se ha eliminado correctamente");
				}else {
					
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			break;
		case 5:
	
			teclado.nextLine();
			String renombrarArchivo;
			
			System.out.println("Introduzca la ruta y un nombre para renombrar la carpeta o fichero");
			nombreFichero = teclado.nextLine();
			
			File renombrar = new File (nombreFichero);
			
			try {
				if (renombrar.renameTo(nombre)) {
					System.out.println("El archivo se ha renombrado correctamente");
				}else {
					
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			break;
			default:
				System.out.println("El numero introducido no corresponde a ninguna funcionalidad");
		}
		
	}
	public static void getInformacion(File f) {
		 
		if (f.isDirectory()) {
			System.out.println("El archivo introducido es un directorio. Este directorio existe y tiene permisos");
			System.out.println("Nombre: " + f.getName());
			System.out.println("Última vez modificado: " + f.lastModified());
			System.out.println("Ubicación de la ruta completa: " + f.getAbsolutePath());
			System.out.println("¿Está oculto?: " + f.isHidden());
			System.out.println("Longitud en bytes: " + f.list().length);
			System.out.println("Espacio libre: " + f.getFreeSpace());
			System.out.println("Espacio disponible: " + f.getUsableSpace());
			System.out.println("Espacio total: " + f.getTotalSpace());
		}
		else if(f.isFile()){
			System.out.println("El archivo introducido es un fichero. Este fichero existe y tiene permisos");
			System.out.println("Nombre: " + f.getName());
			System.out.println("Última vez modificado: " + f.lastModified());
			System.out.println("Ubicación de la ruta completa: " + f.getAbsolutePath());
			System.out.println("¿Está oculto?: " + f.isHidden());
			System.out.println("Longitud en bytes: " + f.list().length);
			System.out.println("Espacio libre: " + f.getFreeSpace());
			System.out.println("Espacio disponible: " + f.getUsableSpace());
			System.out.println("Espacio total: " + f.getTotalSpace());
		}
		
	}
	public static void crearCarpeta(String nombreCarpeta) {
		
		File carpeta = new File (nombreCarpeta);
		
		if (carpeta.mkdir()) {
			System.out.println("La carpeta se ha creado correctamente");
		}else {
			
		}
		
	}
	

}
