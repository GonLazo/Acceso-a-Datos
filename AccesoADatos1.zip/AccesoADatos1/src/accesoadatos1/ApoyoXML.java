/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package accesoadatos1;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author denos
 */
public class ApoyoXML {
    
    List<NotasPOJO> futbolistas = new ArrayList<>();
    
    public void LeerXML(String path) throws SAXException, ParserConfigurationException, IOException{
        
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dbBuilder = dbFactory.newDocumentBuilder();
        Document document = dbBuilder.parse(new File(path));
        
        Element raiz = document.getDocumentElement();
        System.out.println("Contenido XML " + raiz.getNodeName() + ":");
        NodeList nodeList = document.getElementsByTagName("alumno");
        
        for (int i=0;i<nodeList.getLength();i++){
            Node node = nodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE){
                Element eElement = (Element) node;
                NotasPOJO futbolista = new NotasPOJO();
                
                futbolista.setID(Integer.parseInt(eElement.getAttribute("ID")));
                futbolista.setNombre(eElement.getElementsByTagName("nombre").item(0).getTextContent());
                futbolista.setEquipo(eElement.getElementsByTagName("equipo").item(0).getTextContent());
                futbolista.setAnyo(Integer.parseInt(eElement.getAttribute("anyo")));
                futbolista.setPosicion(eElement.getElementsByTagName("posicion").item(0).getTextContent());
                futbolistas.add(futbolista);
            }
        }
    }
    
    public NotasPOJO Read(int index){
        return futbolistas.get(index);
    }
    
    public void Delete(int index){
        futbolistas.remove(index);
    }
    
    public void Create(String equipo, String nombre, int anyo, String posicion ){
        NotasPOJO nuevo = new NotasPOJO();
        
        nuevo.setID(futbolistas.size());
        nuevo.setNombre(nombre);
        nuevo.setEquipo(equipo);
        nuevo.setAnyo(anyo);
        nuevo.setPosicion(posicion);
        futbolistas.add(nuevo);
    }    
    
    public void update(Integer position, String equipo, String nombre, String posicion, int anyo){
        //listaNotas.get(position).setID(id);
        futbolistas.get(position).setNombre(nombre);
        futbolistas.get(position).setEquipo(equipo);
        futbolistas.get(position).setAnyo(anyo);
        futbolistas.get(position).setPosicion(posicion);
    }    

    public int registros(){
        return futbolistas.size();
    }
    
    public void EscribirXML(String path) throws TransformerConfigurationException, TransformerException, ParserConfigurationException{
        // Crear un documento XML vacío
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document doc = docBuilder.newDocument();

        // Crear el elemento raíz
        Element rootElement = doc.createElement("futbolistas");
        doc.appendChild(rootElement);

        for (NotasPOJO notas: futbolistas ){
            
            
            // Agregar elementos y datos al documento
            Element childElement = doc.createElement("futbolista");
            childElement.setAttribute("ID", String.valueOf(notas.getID()));

            // Agregamos bicicleta con ID=1 al root Bicicletas
            rootElement.appendChild(childElement);
            
            
            // Agregar elementos dentro de bicicleta -> marca
            Element equipo = doc.createElement("equipo");
            equipo.appendChild(doc.createTextNode(notas.getEquipo()));        
            childElement.appendChild(equipo);

            // Agregar elementos dentro de bicicleta -> modelo
            Element nombre = doc.createElement("Nombre");
            nombre.appendChild(doc.createTextNode(notas.getNombre()));
            childElement.appendChild(nombre);

            // Agregar elementos dentro de bicicleta -> anyo
            Element anyo = doc.createElement("anyo");
            anyo.appendChild(doc.createTextNode(String.valueOf(notas.getAnyo())));
            childElement.appendChild(anyo);   
            
            // Agregar elementos dentro de bicicleta -> posicion
            Element posicion = doc.createElement("posicion");
            posicion.appendChild(doc.createTextNode(String.valueOf(notas.getPosicion())));
            childElement.appendChild(posicion);

            
        }
        // Guardar el documento XML en un archivo
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();        
        
        // Formateamos el fichero XML
        Properties outputProperties = new Properties();
        
        // Aquí marcamos que la tabulación debe ser de 4 espacios
        outputProperties.setProperty("{http://xml.apache.org/xslt}indent-amount", "4");
        
        // Aquí marcamos que queremos la tabulación
        outputProperties.setProperty(OutputKeys.INDENT, "yes");
        
        // Aquí marcamos que queremos la inicialización del archivo XML
        outputProperties.setProperty(OutputKeys.OMIT_XML_DECLARATION, "no");

        // Aplicamos las propiedades del fichero XML
        transformer.setOutputProperties(outputProperties);  // Opcional: dar formato al archivo

        // Especifica la ruta del archivo en el que deseas guardar el XML
        File xmlFile = new File(path);

        // Guarda el documento XML en el archivo especificado
        Result output = new StreamResult(xmlFile);
        transformer.transform(new DOMSource(doc), output);

        System.out.println("Archivo XML generado correctamente.");
    }
    
}
