/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package accesoadatos1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import org.xml.sax.SAXException;

/**
 *
 * @author DAM2
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private Button anteriorButton;
    @FXML
    private Button siguienteButton;
    @FXML
    private TextField nombre;
    @FXML
    private TextField id;
    @FXML
    private TextField equipo;
    @FXML
    private TextField anyo;
    @FXML
    private TextField posicion;
    @FXML
    
    
    Integer position;
    
    ApoyoXML datos = new ApoyoXML();
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        position = 0;
        
        try {
            datos.LeerXML("datos.xml");
            
            NotasPOJO NotaInicial = new NotasPOJO();
            NotaInicial=datos.Read(0);
            id.setText(String.valueOf(NotaInicial.getID()));
            nombre.setText(NotaInicial.getNombre());
            equipo.setText(NotaInicial.getEquipo());
            anyo.setText(String.valueOf(NotaInicial.getAnyo()));
            posicion.setText(NotaInicial.getPosicion());
            
            
        } catch (SAXException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            datos.EscribirXML("hola.xml");
        } catch (TransformerException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void anteriorButtonAction(ActionEvent event) {
    }

    @FXML
    private void siguienteButtonAction(ActionEvent event) {
        position++;
        
        if(position==datos.registros()){
            id.setText(" ");
            nombre.setText(" ");
            equipo.setText(" ");
            anyo.setText(" ");   
            posicion.setText(" "); 
        }
        else{
            datos.Read(position);
        }
    }
    
}
